
class MockApiClient {
  MockApiClient();

  static const _jsonDir = 'assets/json/';
  static const _jsonExtension = '.json';


  Future<dynamic> mockApiCallEmptyResponse() async {
    /**
     * For throwing exception uncomment below code.
     */

    return "";
  }
}
