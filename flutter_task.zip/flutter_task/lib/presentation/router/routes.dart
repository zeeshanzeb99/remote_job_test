const SPLASH_SCREEN_ROUTE = "/splashScreenRoute";
const MAIN_SCREEN_ROUTE = "/mainScreenRoute";
const PRODUCT_SCREEN = "/allProductsScreen";
const CATEGORY_SCREEN = "/categoryScreen";
const CATEGORY_DETAILS_SCREEN = "/categoryDetailsScreen";

const PRODUCT_DETAILS_SCREEN = "/productDetailsScreen";