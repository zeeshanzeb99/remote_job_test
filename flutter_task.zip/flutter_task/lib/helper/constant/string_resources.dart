
class StringResources {
  static const String products = 'Products';
  static const String categories = 'Categories';
  static const String favourites = 'Favourites';
  static const String mittKonto = 'Zeeshan';
  static const String email = 'zeeshan@gmail.com';
  static const String phNo = '03XXXXXXXX';
  static const String settings = " Kontoinstallningar";
  static const String cash = "Mina betalmetoder";
  static const String support = " Support";
  static const String search = " search";
  static const String result_found = "results found";
  static const String product_details = "Product Details";
  static const String name = 'Name:';
  static const String price = 'Price :';
  static const String brand = 'Brand:';
  static const String category = 'Category :';
  static const String rating = 'Rating :';
  static const String stock = 'Stock :';
  static const String description = 'Description :';
  static const String gallery = 'Product Gallery :';



}