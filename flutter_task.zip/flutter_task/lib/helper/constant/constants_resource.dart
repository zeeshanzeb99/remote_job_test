class ConstantsResource {

  static const SPLASH_DELAY = 3;
  static const SNACKBAR_DURATION = 2;
  static const APP_NAME = "Flutter Test";
  static const CONTENT_TYPE = 'application/json';
  static const double APP_DESIGN_WIDTH = 375;
  static const double APP_DESIGN_HEIGHT = 812;
  static const itemLimit = 100;


}
